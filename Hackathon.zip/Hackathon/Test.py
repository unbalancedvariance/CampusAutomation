import requests

pload = {'username':'IMT2020529','password':'hehe'}
plod1 = { 'Year' : '2020',
          'Month': 'Jan',
          'Day'  : '24',
          'Hour' : '35',
          'minute': '37',
          'student_Roll' :'IMT2020545',
          'Supervision' : 'YES',
        
        }

r2  = requests.post("http://a72c-103-197-113-24.ngrok.io/Requests",data = plod1)
r = requests.post('http://a72c-103-197-113-24.ngrok.io',data = pload)

print(r.text)
