from django.shortcuts import render,HttpResponse
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Student,Request
import json
from .Serializers import StudentSerilizer,RequestSerializer


# Create your views here.
@api_view(['POST'])
def catch(request):
	print(request.data)
	print(request.data['username'])
	print(request.data['password'])

	starset = Student.objects.all()
	ser = StudentSerilizer()

	for star in starset.iterator():
		if(star.Roll_num == request.data['username']):
			if(star.password == request.data['password']):
				ser = StudentSerilizer(star)
				return Response(ser.data)

	return Response(status = HTTP_200_OK)



@api_view(['POST']) #Add
def Handle(request):
	print(request.data['Year'])
	Year = request.data['Year']
	Month = request.data['Month']
	Day = request.data['Day']
	Hour = request.data['Hour']
	minute = request.data['minute']
	student_Roll = request.data['student_Roll']
	wantCleanImm = request.data['Supervision']
	if((wantCleanImm == 'YES') or (wantCleanImm == 'Yes')):
		wantCleanImm = True

	new_request = Request(Year = Year,Month = Month,Day = Day,Hour = Hour,minute = minute,student_Roll = student_Roll,wantCleanImm = wantCleanImm)
	new_request.save()

	return Response(status = HTTP_200_OK)



@api_view(['GET','POST'])
def Return(request):

	Rs = Request.objects.all()
	num = len(Rs)

	List = []

	"""

	count = 1
	for i in Rs.iterator():
		List.append({
			"id" : f"{count}",
			"Year" : f"{i.Year}",
			"Month" : f"{i.Month}", 
			"Day" : f"{i.Day}",
			"Hour" : f"{i.Hour}",
			"minute" : f"{i.minute}",
			"student_Roll" : f"{i.student_Roll}",
			"Supervision" : f"{i.wantCleanImm}"
			})

		count += 1

	"""
	ser = RequestSerializer(Rs,many = True)

	return Response(ser.data)