from django.db import models
from datetime import datetime 
# Create your models here.

class Student(models.Model):
	Roll_num = models.CharField(max_length = 30,default = '')
	password = models.CharField(max_length = 30,default = '')
	name = models.CharField(max_length = 30,default = '')
	Room_num = models.CharField(max_length = 30,default = '')
	

	def __str__(self):
		return "Student object"



class Request(models.Model):
	Year = models.CharField(max_length = 30,default = '')
	Month = models.CharField(max_length = 30,default = '')
	Day = models.CharField(max_length = 30,default = '')
	Hour = models.CharField(max_length = 30,default = '')
	minute = models.CharField(max_length = 30,default = '')

	student_Roll = models.CharField(max_length = 30,default = '')
	wantCleanImm = models.CharField(max_length = 30,default = 'YES')
	isCompleted = models.BooleanField(default = False)
	
	def __str__(self):
		return "Request Object"


class LaundryRequest(models.Model):
	Year = models.CharField(max_length = 30,default = '')
	Month = models.CharField(max_length = 30,default = '')
	Day = models.CharField(max_length = 30,default = '')
	Hour = models.CharField(max_length = 30,default = '')

	minute = models.CharField(max_length = 30,default = '')
	student_Roll = models.CharField(max_length = 30,default = '')
	wantCleanImm = models.CharField(max_length = 30,default = 'YES')
	isCompleted = models.BooleanField(default = False)

	def __str__(self):
		return "Laundry Request object"







