
from django.urls import path
from .views import catch,Handle,Return

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('Post',catch),
    path('Requests/',Handle),
    path('get/',Return)

]
