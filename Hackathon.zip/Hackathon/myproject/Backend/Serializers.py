from rest_framework.serializers import ModelSerializer
from .models import Student,Request


class StudentSerilizer(ModelSerializer):
	class Meta:
		model = Student
		fields = '__all__'


class RequestSerializer(ModelSerializer):
	class Meta:
		model = Request
		fields = '__all__'