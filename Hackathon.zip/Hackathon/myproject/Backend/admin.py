from django.contrib import admin
from .models import Student,Request

# Register your models here.
admin.site.register(Student)
admin.site.register(Request)